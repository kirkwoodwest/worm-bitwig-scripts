function TrackHandler(trackbank, cursorTrack, massiveBank, fader_cc, track_name) {
   this.track_name = track_name;
   this.trackbank = trackbank;
   this.cursorTrack = cursorTrack;
   this.massiveBank = massiveBank;
   
   this.fader_cc = fader_cc;
   this.targetScrollIndex = 0;
   this.baseChannel = null;
   this.deviceBanks = [];

   //remote pages
   remoteKnobs1 = [KNOB_A_1, KNOB_A_2, KNOB_A_3, KNOB_A_4];
   remoteKnobs2 = [KNOB_A_5, KNOB_A_6, KNOB_A_7, KNOB_A_8];
   remoteKnobs3 = [KNOB_A_9, KNOB_A_10, KNOB_A_11, KNOB_A_12];
   remoteKnobs4 = [KNOB_A_13, KNOB_A_14, KNOB_A_15, KNOB_A_16];
   
   this.remoteKnobs = [remoteKnobs1,remoteKnobs2,remoteKnobs3,remoteKnobs4];
   this.cursorRemotes = []

   //this.trackbank.itemCount.markInterested()
   for (i=0;i <this.trackbank.getSizeOfBank(); i++){
      var track = this.trackbank.getItemAt(i);

      this.deviceBanks.push(track.createDeviceBank(1));

      var device = this.deviceBanks[i].getDevice(0);
      
      for(i=0;i<this.remoteKnobs.length;i++){
         this.cursorRemotes.push(device.createCursorRemoteControlsPage('yo'+i, 8,'drums'+i));
         this.cursorRemotes[i].selectedPageIndex().markInterested();
//         this.cursorRemotes[i].selectedPageIndex(i)
      }

      var p = track.pan();
      p.markInterested();
      p.setIndication(true);

      p = track.volume();
      p.markInterested();
      p.setIndication(true);

      p = track.name();
      p.markInterested();
   }
   this.trackbank.itemCount().markInterested();
   this.massiveBank.itemCount().markInterested();
   for(i=0;i< this.massiveBank.getSizeOfBank();i++){
      var track = this.massiveBank.getItemAt(i);
      p = track.name();
      p.markInterested();
   }
   this.trackbank.scrollPosition().markInterested();
   this.cursorTrack.isPinned().markInterested();
   this.moveToProperTrack()
}

TrackHandler.prototype.moveToProperTrack = function() {
   var massiveBankCount = this.massiveBank.itemCount().get();
   var trackBankCount = this.trackbank.itemCount().get();

   println('massiveBankCount' + massiveBankCount);
   println(' this.track_name' +  this.track_name);

   //Determine if we have initialized the proper track...
   if ( massiveBankCount == 0 || trackBankCount == 0){
      host.scheduleTask(doObject(this, this.moveToProperTrack), 1000);
      return;
   }

   //Loop through the massive Bank... assuming its everything....
   targetScrollIndex = 0;
   for(i=0;i< this.massiveBank.getSizeOfBank();i++){
      println('this.massiveBank.getItemAt(i).name().get()' + this.massiveBank.getItemAt(i).name().get());
      if ( this.massiveBank.getItemAt(i).name().get()  == this.track_name ) {
         this.baseChannel = this.massiveBank.getItemAt(i);
         targetScrollIndex = i
         this.targetScrollIndex = targetScrollIndex
         break;
      }
   }

   println('this.targetScrollIndex' + this.targetScrollIndex);
   println('this.trackbank.scrollPosition().get()' + this.trackbank.scrollPosition().get());
   
   if(this.trackbank.scrollPosition() == undefined){
      println(' (this.trackbank.scrollPosition() == undefined){');
   }
   if (this.trackbank.scrollPosition().get() != targetScrollIndex){
      //Attempt ot set the scroll position....
      this.trackbank.scrollPosition().set(targetScrollIndex);
      
      //restart it.
      host.scheduleTask(doObject(this, this.moveToProperTrack), 1000);
      host.scheduleTask(doObject(this, this.selectParent), 1000);
      return;
   }
}

TrackHandler.prototype.selectParent = function(){
   this.cursorTrack.selectChannel(this.baseChannel);
   this.cursorTrack.isPinned().set(true);
}

TrackHandler.prototype.handleMidi = function(status, data1, data2) {
   var success = false

   //this.moveToProperTrack();
//
   if (isChannelController(status)){
      switch(data1){
         case this.fader_cc:
            this.trackbank.getItemAt(0).volume().set(data2, 128);
            success = true;
            break;
            /*
         case FADER_6:
            this.trackbank.getItemAt(1).volume().set(data2, 128);
            success = true;
            break;
         case FADER_7:
            this.trackbank.getItemAt(2).volume ().set(data2, 128);
            success = true;
            break;
         case FADER_8:
            this.trackbank.getItemAt(3).volume ().set(data2, 128);
            success = true;
            break;
            */
      }
   }


  /* 
   if (isNoteOn(status) && data2 == 127) {
      println("Process is happening");
      switch (data1) {
         case FIRST_BTN_B_1:
           //println(getMethodsNames(this.trackbank));
           
           this.trackbank.scrollIntoView(-4);
           
          // this.trackbank.cursorIndex(1)
            success = true;
            break;
         case FIRST_BTN_B_2:
            //this.trackbank.scrollPageForwards()
            this.trackbank.scrollIntoView(5);
            println("cursor index: " +this.trackbank.cursorIndex()); 
            success = true;
            break;
         case FIRST_BTN_B_3:
            //this.trackbank.scrollPageForwards()
            track = this.trackbank.getItemAt(1);
            println("say my name: " +track.name().get() ); 
           // track.setName("blah" + Math.random())
           
            success = true;
            break;
      }
      println("SCROLLPOSITION index: " +this.trackbank.scrollPosition());
   }

   */
   return success;
}
